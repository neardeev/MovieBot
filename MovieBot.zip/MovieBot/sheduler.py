from apscheduler.schedulers.background import BackgroundScheduler
import time
from db.execution import execute


def delete_expired_reservations():
    execute(["""DELETE FROM pheck  WHERE r_id in (select r_id from res where pay = 0)"""])
    execute(["DELETE FROM res WHERE e_time < NOW() AND pay = 0"])

def run_scheduler():
    scheduler = BackgroundScheduler()
    scheduler.add_job(delete_expired_reservations, 'interval', minutes=1)
    scheduler.start()
    print("Планировщик запущен.")
    try:
        while True:
            time.sleep(10)
    except (KeyboardInterrupt, SystemExit):
        scheduler.shutdown()

