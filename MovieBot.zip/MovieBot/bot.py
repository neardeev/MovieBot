import telebot
from handlers import register_handlers
from dotenv import load_dotenv
from sheduler import run_scheduler
import threading
import os
load_dotenv()
TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
bot = telebot.TeleBot(TOKEN)

register_handlers(bot)

if __name__ == '__main__':
    threading.Thread(target=run_scheduler).start()
    print("Бот запущен...")
    bot.infinity_polling()
