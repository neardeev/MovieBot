from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from db.fetchall import fetchall

from db.trial2 import trial2
from db.execution import execute
from datetime import datetime, timedelta
import io
import stripe

from PIL import Image, ImageDraw, ImageFont

ADMINS = []

user_states = {}




def register_admin(bot):
    def reset_user_state(user_id):
        user_states.pop(user_id, None)
    def safe_register_next_step_handler(message, user_id, expected_state, handler, *args):
        print(message.from_user.id)
        def wrapped_handler(msg):
            if user_states.get(user_id) == expected_state:
                handler(msg, *args)
            else:
                bot.send_message(msg.chat.id, "Процесс был прерван. Начните заново при необходимости.")

        bot.register_next_step_handler(message, wrapped_handler)

    def notification(av_ids):
        av_id_list = [av_id[0] for av_id in av_ids]
        placeholders = ','.join(['%s'] * len(av_id_list))
        select = fetchall(f"select distinct cl_name from res where av_id in ({placeholders})", av_id_list)

        cl_names = [cl_name[0] for cl_name in select]

        select = fetchall(f"select distinct r_id from res where av_id in ({placeholders})", av_id_list)

        res_ids = [res_id[0] for res_id in select]
        for res_id in res_ids:
            subselect = fetchall("select pay from res where r_id = (%s)", [res_id])
            pay = subselect[0][0]

            if pay == 0:
                trial2("delete from pheck where r_id = (%s)", [res_id])
                trial2("delete from res where r_id = (%s)", [res_id])

            else:
                subselect = fetchall("select sc_id from pheck where r_id = (%s)", [res_id])
                trial2("delete from pheck where r_id = (%s)", [res_id])
                trial2("delete from res where r_id = (%s)", [res_id])
                payment_id = subselect[0][0]

                try:
                    intent = stripe.PaymentIntent.retrieve(payment_id)
                    charge = intent.charges.data[0].id
                    stripe.Refund.create(charge=charge)
                except Exception as e:
                    print(f"❌ Ошибка: {e}")
        for client_name in cl_names:
            try:
                bot.send_message(client_name, "⚠️ Ваш сеанс был отменён. Извините за неудобства.")
            except Exception as e:
                print(f"Не удалось отправить сообщение пользователю {client_name}: {e}")

    def demostrate(date):
        av_date = datetime.strptime(date, "%d.%m.%Y").date()
        select = fetchall(
            "select av_name, av_date, av_time, av_delta, av_price, h_name, COUNT(distinct r_id) FILTER (WHERE pay = 1), count(distinct seats.seat_id) - count(DISTINCT r_id) FILTER (WHERE pay = 1) from av left join halls using(h_id) left join res using(av_id) left join seats using(h_id) group by av_name, av_date, av_time, av_delta, av_price, h_name having av_date between (%s) and  ((%s) + (CAST(10 AS TEXT) || 'days')::INTERVAL)  order by  av_date ASC, av_time ASC ",
            [av_date, av_date])
        return select

    def generate_schedule_image(data, definition):
        if not data:
            return None


        font = ImageFont.truetype("arial.ttf", size=18)
        bold_font = ImageFont.truetype("arialbd.ttf", size=20)
        cell_padding = 10
        row_height = 40
        column_widths = [200, 100, 80, 200, 80, 120, 120, 150]

        headers = ["Название", "Дата", "Время", "Длительность", "Цена", "Зал", "Броней", "Свободно"]


        width = sum(column_widths) + cell_padding * 2
        height = row_height * (len(data) + 2)

        img = Image.new("RGB", (width, height), "white")
        draw = ImageDraw.Draw(img)


        draw.text((cell_padding, 5), definition , font=bold_font, fill="black")


        y = row_height
        x = cell_padding
        for i, header in enumerate(headers):
            draw.text((x, y), header, font=bold_font, fill="black")
            x += column_widths[i]


        for idx, row in enumerate(data):
            av_name, av_date, av_time, av_delta, av_price, h_name, booked, remaining = row
            av_date = av_date.strftime("%d.%m.%Y")
            av_time = str(av_time)[:5]
            values = [av_name, av_date, av_time, f"{av_delta} мин", f"{av_price} ₽", h_name, str(booked),
                      str(remaining)]

            y = row_height * (idx + 2)
            x = cell_padding
            for i, value in enumerate(values):
                draw.text((x, y), value, font=font, fill="black")
                x += column_widths[i]

        return img


    def show_admin_panel(chat_id):
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("Добавить информацию о фильмах🪄", callback_data="edit"))
        markup.add(InlineKeyboardButton("Манипуляции🧹", callback_data="lobby"))
        markup.add(InlineKeyboardButton("Создать залы 🪄", callback_data="halls"))
        markup.add(InlineKeyboardButton("Добавить сеанс фильма 🖋️", callback_data="add_session"))
        markup.add(InlineKeyboardButton("Информация о фильмах📖", callback_data="about_sessions"))
        bot.send_message(chat_id, "Админ-панель 🔧", reply_markup=markup)



    def admin_check_access_message(message):
        """Проверка доступа для message"""
        if message.from_user.id not in ADMINS:
            bot.reply_to(message, "У вас нет доступа к этой функции.")
            return False
        return True


    def admin_check_access(call):
        """Проверка доступа для call"""
        if call.from_user.id not in ADMINS:
            bot.answer_callback_query(call.id, "У вас нет доступа к этой функции.")
            return False
        return True

    def get_sessions_info(call):
        """Вывод кнопок выбора опции своей декады или
        автоматически предложенной """
        bot.answer_callback_query(call.id)
        sessions_info_markup = get_sessions_info_buttons()

        bot.send_message(call.message.chat.id,
                         "В этом разделе есть возможность посмотреть информацию о сеансах по декадам.\nВыберете предложенную или введите свою",
                         reply_markup=sessions_info_markup)

    def get_sessions_info_buttons():
        """Создали кнопки выбора своего промежутка или автоматического,
        получили сегодняшний день,
        прибавили к нему 10 дней"""
        sessions_info_markup = InlineKeyboardMarkup()

        curr_time = datetime.now().date().strftime("%d.%m.%Y")
        fut_time = (datetime.now().date() + timedelta(days=10)).strftime("%d.%m.%Y")

        sessions_info_markup.add(InlineKeyboardButton(f"Начиная с: {curr_time} по {fut_time}",
                                        callback_data=f"curr_decade|{curr_time}|{fut_time}"))
        sessions_info_markup.add(InlineKeyboardButton(f"Ввести свое значение", callback_data=f"input_decade"))
        sessions_info_markup.add(InlineKeyboardButton("Назад к панели администратора ↩️", callback_data="admin"))

        return sessions_info_markup

    def get_sessions_schedule(call):
        """Переход если выбрана предложенная декада,
        вывод фото при успехе, иначе уведомление об обратном.
        Вывод кнопки для вызова панели администрации"""
        schedule_markup = InlineKeyboardMarkup()
        _, curr_time, fut_time = call.data.split("|")

        img_byte = get_sessions_schedule_make(curr_time, fut_time)
        if img_byte:
            schedule_markup.add(InlineKeyboardButton("Назад к панели администратора ↩️", callback_data="admin"))
            bot.send_photo(call.message.chat.id, img_byte, reply_markup=schedule_markup)
        else:
            schedule_markup.add(InlineKeyboardButton("Назад к панели администратора ↩️", callback_data="admin"))
            bot.send_message(call.message.chat.id, "Нет сеансов на выбранный период.", reply_markup=schedule_markup)


    def get_sessions_schedule_make(curr_time, fut_time):
        """Создание самого изображения по ключам дни от - до"""
        data = demostrate(curr_time)
        img = generate_schedule_image(data, f"Расписание с {curr_time} по {fut_time} ")

        img_byte = io.BytesIO()
        img.save(img_byte, format='PNG')
        img_byte.seek(0)
        return  img_byte

    def get_sessions_schedule_yours(call):
        """Если выбрана своя декада, запрос на дату.
        Переход к следующей функции для обработки"""
        user_id = call.from_user.id
        reset_user_state(user_id)
        user_states[call.from_user.id] = "decading"
        get_sessions_schedule_your_markup = InlineKeyboardMarkup()

        get_sessions_schedule_your_markup.add(InlineKeyboardButton(" Прервать процесс ⛓️‍💥", callback_data="cancel"))
        msg = bot.send_message(call.message.chat.id, "Введите день (формат дд.мм.гг):", reply_markup=get_sessions_schedule_your_markup)

        safe_register_next_step_handler(msg, user_id, "decading", dec_day)

    def dec_day(message):
        """Обработка даты, проверка статуса взаимодействия, кнопка прерывания процесса
        Далее создание как на предыдущем шаге"""
        user_id = message.from_user.id
        if user_states.get(message.from_user.id) != "decading":
            return
        if not admin_check_access_message(message):
            return

        dec_day_markup = InlineKeyboardMarkup()

        date = message.text.strip()

        try:
            date = datetime.strptime(date, "%d.%m.%Y").date()
        except ValueError:
            dec_day_markup.add(InlineKeyboardButton(" Прервать процесс ⛓️‍💥", callback_data="cancel"))
            msg = bot.send_message(message.chat.id, "Неверный формат даты. Введите дату в формате дд.мм.гг:",
                             reply_markup=dec_day_markup)
            bot.register_next_step_handler(msg, user_id, "decading", dec_day)
            return
        fut_time = (date + timedelta(days=10)).strftime("%d.%m.%Y")
        start_date = date.strftime("%d.%m.%Y")


        img_byte = get_sessions_schedule_make(start_date, fut_time)
        if img_byte:
            dec_day_markup.add(InlineKeyboardButton("Назад к панели администратора ↩️", callback_data="admin"))
            bot.send_photo(message.chat.id, img_byte, reply_markup=dec_day_markup)
        else:
            dec_day_markup.add(InlineKeyboardButton("Назад к панели администратора ↩️", callback_data="admin"))
            bot.send_message(message.chat.id, "Нет сеансов на выбранный период.", reply_markup=dec_day_markup)

    def choose_option(call):
        """Вывод кнопок с фильмами, возникает при нажатии кнопки манипуляции"""
        choose_option_markup = choose_option_list()

        bot.send_message(call.message.chat.id, "Перед началом выберите фильм: ", reply_markup=choose_option_markup)

    def choose_option_list():
        """Выборка фильмов, создание кнопок"""
        choose_option_markup = InlineKeyboardMarkup()
        select = fetchall("SELECT DISTINCT av_name FROM av", "")
        for movie in select:
            movie = movie[0]
            choose_option_markup.add(InlineKeyboardButton(f"{movie}", callback_data=f"options|{movie}"))
        choose_option_markup.add(InlineKeyboardButton("Назад к панели администратора ↩️", callback_data="admin"))

        return choose_option_markup

    def get_deletion(call):
        """Создание кнопок с опциями,
        переход происходит при нажатии на фильм"""
        _, movie = call.data.split("|")
        markup = get_deletion_button(movie)

        bot.send_message(call.message.chat.id, "Выберите опцию: ", reply_markup=markup)

    def get_deletion_button(movie):
        """Создание кнопок, возвращает кнопку"""
        get_deletion_markup = InlineKeyboardMarkup()
        get_deletion_markup.add(InlineKeyboardButton(f"Удалить 🗑️", callback_data=f"destroy|{movie}"))
        get_deletion_markup.add(InlineKeyboardButton("Назад к панели администратора ↩️", callback_data="admin"))

        return get_deletion_markup

    def choose_option_to_delete(call):
        """Запрос на то как удалить,
        при нажатии на кнопку удалить"""
        _, movie = call.data.split("|")
        choose_to_delete_markup = choose_option_to_delete_button(movie)

        bot.send_message(call.message.chat.id, "Изъять из проката: ", reply_markup=choose_to_delete_markup)

    def choose_option_to_delete_button(movie):
        """Создание кнопок с опциями"""
        choose_to_delete_markup = InlineKeyboardMarkup()

        choose_to_delete_markup.add(InlineKeyboardButton(f"Полностью", callback_data=f"des_all|{movie}"))
        choose_to_delete_markup.add(InlineKeyboardButton(f"Определенный день", callback_data=f"des_day|{movie}"))
        choose_to_delete_markup.add(InlineKeyboardButton(f"Определенное время", callback_data=f"des_time_for|{movie}"))
        choose_to_delete_markup.add(InlineKeyboardButton("Назад к панели администратора ↩️", callback_data="admin"))
        return choose_to_delete_markup

    def ask_to_delete(call):
        """Если нажато полностью"""
        _, movie = call.data.split("|")
        ask_to_delete_markup = ask_to_delete_button(movie)

        bot.send_message(call.message.chat.id, f"Вы уверены, что хотите удалить ВСЕ сеансы фильма: {movie}?",
                         reply_markup=ask_to_delete_markup)

    def ask_to_delete_button(movie):
        """Создание кнопок с подтверждением действий"""
        ask_to_delete_markup = InlineKeyboardMarkup()

        ask_to_delete_markup.add(InlineKeyboardButton(f"Да", callback_data=f"desa_ok|{movie}"))
        ask_to_delete_markup.add(InlineKeyboardButton(f"Нет", callback_data=f"renew|{movie}"))
        ask_to_delete_markup.add(InlineKeyboardButton("Назад к панели администратора ↩️", callback_data="admin"))
        return ask_to_delete_markup

    def delete(call):
        """Удаление при нажатии да"""
        _, movie = call.data.split("|")
        delete_markup = delete_button(movie)

        bot.send_message(call.message.chat.id, f"Сеансы были удалены",
                         reply_markup=delete_markup)

    def delete_button(movie):
        """Процесс удаления из таблицы + функция уведомления юзеров.
        Создание кнопок"""
        delete_markup = InlineKeyboardMarkup()

        available_id = fetchall("SELECT DISTINCT av_id FROM av WHERE av_name = (%s)", [movie])
        notification(available_id)
        trial2("DELETE FROM av WHERE av_name = (%s)", [movie])

        delete_markup.add(InlineKeyboardButton("Назад к панели администратора ↩️", callback_data="admin"))
        return delete_markup

    def destroy_some(call):
        """Удаление в рамках одного дня, при нажатии определенный день.
        Запрос от юзера даты"""
        user_id = call.from_user.id

        reset_user_state(user_id)

        user_states[call.from_user.id] = "destroying_time"
        _, movie = call.data.split("|")
        markup = InlineKeyboardMarkup()

        markup.add(InlineKeyboardButton(" Прервать процесс ⛓️‍💥", callback_data="cancel"))
        msg = bot.send_message(call.message.chat.id, "Введите день (формат дд.мм.гг):", reply_markup=markup)

        safe_register_next_step_handler(msg, user_id, "destroying_time", lambda message: day_des(message, movie))


    def day_des(message, movie):
        """Проверка даты на корректность + запрос времени"""
        user_id = message.from_user.id
        if user_states.get(message.from_user.id) != "destroying_time":
            return
        if not admin_check_access_message(message):
            return
        markup = InlineKeyboardMarkup()

        date = message.text.strip()


        try:
            date = datetime.strptime(date, "%d.%m.%Y").date()
        except ValueError:
            markup.add(InlineKeyboardButton(" Прервать процесс ⛓️‍💥", callback_data="cancel"))
            msg = bot.send_message(message.chat.id, "Неверный формат даты. Введите дату в формате дд.мм.гг:",reply_markup=markup)
            safe_register_next_step_handler(msg, user_id, "destroying_time",seq_des, movie)
            return
        markup.add(InlineKeyboardButton(" Прервать процесс ⛓️‍💥", callback_data="cancel"))
        msg = bot.send_message(message.chat.id,
                         f"Введите для {date}  время (формат чч:мм), несколько времен (формат чч:мм,чч:мм):",
                         reply_markup=markup)
        safe_register_next_step_handler(msg, user_id,"destroying_time",time_des, movie, date)


    def time_des(message, movie, date):
        """Проверка времени + удаление по ключам названия, даты, времени"""
        user_id = message.from_user.id
        if user_states.get(message.from_user.id) != "destroying_time":
            return
        if not admin_check_access_message(message):
            return
        markup = InlineKeyboardMarkup()

        times = message.text.strip().split(",")

        try:
            times = [datetime.strptime(time, "%H:%M").time() for time in times]
        except ValueError:
            msg = bot.send_message(message.chat.id, "Неверный формат времени. Попробуйте еще:")
            safe_register_next_step_handler(msg,user_id, "destroying_time",  time_des, movie)
            return

        placeholders = ', '.join(['%s'] * len(times))
        select = fetchall(f"SELECT av_id FROM av WHERE av_name = %s AND av_date = %s AND av_time IN ({placeholders})",
                          [movie] + [date] + times)
        notification(select)
        user_states.pop(message.from_user.id, None)
        trial2(f"DELETE FROM av WHERE av_name = (%s) AND av_date = %s AND av_time IN ({placeholders})", [movie] + [date] + times)
        markup.add(InlineKeyboardButton("Назад к панели администратора ↩️", callback_data="admin"))

        bot.send_message(message.chat.id, f"Сеансы были удалены",
                         reply_markup=markup)


    def destroy_day(call):
        """Аналогично предыдущему, но для нескольких дней"""
        user_id = call.from_user.id
        reset_user_state(user_id)
        user_states[call.from_user.id] = "destroying_day"
        _, movie = call.data.split("|")
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton(" Прервать процесс ⛓️‍💥", callback_data="cancel"))
        msg = bot.send_message(call.message.chat.id, "Введите день (формат дд.мм.гг), дни (формат дд.мм.гг,дд.мм,гг):",
                         reply_markup=markup)

        safe_register_next_step_handler(msg, user_id, "destroying_day", lambda message: seq_des(message, movie))

    def seq_des(message, movie):
        user_id = message.from_user.id
        if user_states.get(message.from_user.id) != "destroying_day":
            return
        if message.from_user.id not in ADMINS:
            bot.reply_to(message, "У вас нет доступа к этой функции.")
            return

        markup = InlineKeyboardMarkup()

        dates = message.text.strip().split(",")

        try:
            dates = [datetime.strptime(date, "%d.%m.%Y").date() for date in dates]
        except ValueError:
            markup.add(InlineKeyboardButton(" Прервать процесс ⛓️‍💥", callback_data="cancel"))
            msg = bot.send_message(message.chat.id, "Неверный формат даты. Введите дату в формате дд.мм.гг:",reply_markup=markup)
            safe_register_next_step_handler(msg, user_id, "destroying_day" ,seq_des, movie)
            return

        placeholders = ', '.join(['%s'] * len(dates))
        select = fetchall(f"select distinct av_id from av where av_name = %s and av_date in ({placeholders})",
                          [movie] + dates)

        notification(select)
        trial2(f"delete from av where av_name = (%s) and av_date in ({placeholders})", [movie] + dates)
        markup.add(InlineKeyboardButton("Назад к панели администратора ↩️", callback_data="admin"))

        bot.send_message(message.chat.id, f"Сеансы были удалены",
                         reply_markup=markup)

    def make_halls(call):
        """Создание залов, запрос на имя зала"""
        bot.answer_callback_query(call.id)

        user_id = call.from_user.id
        reset_user_state(user_id)
        user_states[call.from_user.id] = "adding_halls"

        halls_markup = make_halls_list()
        msg = bot.send_message(call.message.chat.id, "Введите название зала:", reply_markup=halls_markup)

        safe_register_next_step_handler(msg, user_id, "adding_halls", add_halls)

    def make_halls_list():
        """Создание табличек для рядов, залов, мест """
        halls_markup = InlineKeyboardMarkup()
        if execute(['select * from halls']) == 1:
            execute(["CREATE TABLE  IF NOT EXISTS halls (h_name VARCHAR(30) NOT NULL)"])
            execute(["ALTER TABLE halls add h_id BIGSERIAL PRIMARY KEY"])
        if execute(['select * from rows']) == 1:
            execute(["CREATE TABLE IF NOT EXISTS rows (h_id INT REFERENCES halls(h_id), row_number INT NOT NULL)"])
            execute(["ALTER TABLE rows add row_id BIGSERIAL PRIMARY KEY"])
        if execute(['select * from seats']) == 1:
            execute([
                "CREATE TABLE IF NOT EXISTS seats (h_id INT REFERENCES halls(h_id), row_id INT REFERENCES rows(row_id), seat_number INT NOT NULL)"])
            execute(["ALTER TABLE seats add seat_id BIGSERIAL PRIMARY KEY"])

        halls_markup.add(InlineKeyboardButton("Прервать процесс ⛓️‍💥", callback_data="cancel"))
        halls_markup.add(InlineKeyboardButton("Назад к панели администратора ↩️", callback_data="admin"))

        return halls_markup

    def add_halls(message):
        """Проверка на корректность введения, вставка зала в таблицу,
        запрос на ряды"""
        user_id = message.from_user.id
        if user_states.get(message.from_user.id) != "adding_halls":
            return

        if not admin_check_access_message(message):
            return
        markup = InlineKeyboardMarkup()
        hall = message.text.strip()

        if not hall:
            bot.send_message(message.chat.id, "Пожалуйста, введите название.")
            return
        trial2("INSERT INTO halls(h_name) VALUES(%s)", [hall])
        markup.add(InlineKeyboardButton(" Прервать процесс ⛓️‍💥", callback_data="cancel"))
        msg = bot.send_message(message.chat.id, "Введите Количество рядов для зала:", reply_markup=markup)


        safe_register_next_step_handler(msg, user_id,"adding_halls", select_rows, hall)


    def select_rows(message, hall):
        """Проверка то что число залов является числом, выбирается ай ди зала,
        запуск рекурсии"""
        if user_states.get(message.from_user.id) != "adding_halls":
            return

        if not admin_check_access_message(message):
            return
        try:
            row_number = int(message.text.strip())
        except ValueError:
            bot.send_message(message.chat.id, "Введите корректное число.")
            return add_halls(message)

        select = fetchall("SELECT h_id FROM halls WHERE h_name = (%s)", [hall])
        h_id = select[0][0]
        ask_seats_for_row(message, h_id, 1, row_number)



    def ask_seats_for_row(message, h_id, current_row, total_rows):
        user_id = message.from_user.id
        print(user_id)
        """Запрос на количество мест"""
        if user_states.get(message.from_user.id) != "adding_halls":
            return

        if not admin_check_access_message(message):
            return
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton(" Прервать процесс ⛓️‍💥", callback_data="cancel"))
        msg = bot.send_message(message.chat.id, f"Введите количество мест для ряда {current_row}:", reply_markup=markup)


        safe_register_next_step_handler(msg, user_id, "adding_halls" ,process_seats_for_row, h_id, current_row, total_rows)


    def process_seats_for_row(message, h_id, current_row, total_rows):
        """Вставляется ай ди зала, плюс текущий ряд.
        Если текущий номер ряда меньше общего количество,
        то со значением +1 к прошлой функции """
        if not admin_check_access_message(message):
            return
        try:
            seats = int(message.text.strip())
        except ValueError:
            bot.send_message(message.chat.id, "Введите корректное число.")
            return ask_seats_for_row(message, h_id, current_row, total_rows)
        trial2("INSERT INTO rows(h_id, row_number) VALUES(%s,%s)", [h_id, current_row])
        select = fetchall("SELECT row_id FROM rows WHERE h_id = (%s) AND row_number = (%s)", [h_id, current_row])
        row_id = select[0][0]

        for i in range(1, seats + 1):
            trial2("INSERT INTO seats(h_id, row_id, seat_number) VALUES(%s,%s,%s)", [h_id, row_id, i])
        if current_row < total_rows:

            ask_seats_for_row(message, h_id, current_row + 1, total_rows)
        else:
            user_states.pop(message.from_user.id, None)
            markup = InlineKeyboardMarkup()
            markup.add(InlineKeyboardButton("Назад к панели администратора ↩️", callback_data="admin"))
            bot.send_message(message.chat.id, "Все ряды и места успешно добавлены ✔️", reply_markup=markup)

    def add_sessions(call):
        """Процесс добавления фильма"""
        user_id = call.from_user.id
        reset_user_state(user_id)
        user_states[call.from_user.id] = "adding_film"
        bot.answer_callback_query(call.id)
        add_sessions_markup = add_sessions_button()

        msg = bot.send_message(call.message.chat.id, "Введите название фильма:", reply_markup=add_sessions_markup)
        safe_register_next_step_handler(msg, user_id,  "adding_film", process_film_input)

    def add_sessions_button():
        add_sessions_markup = InlineKeyboardMarkup()

        execute([
            "DELETE FROM halls WHERE h_id IN (select halls.h_id from halls left join rows using(h_id) left join seats using(row_id) where row_number is NULL and seat_number is NULL)"])


        add_sessions_markup.add(InlineKeyboardButton(" Прервать процесс ⛓️‍💥", callback_data="cancel"))
        return add_sessions_markup

    def process_film_input(message):
        user_id = message.from_user.id
        if user_states.get(message.from_user.id) != "adding_film":
            return
        if not admin_check_access_message(message):
            return
        if execute(["select * from av"]) == 1:
            execute([
                "CREATE TABLE  IF NOT EXISTS av (av_time time, av_date date, av_name VARCHAR(30),h_id INT REFERENCES halls(h_id), av_price INT, av_delta INT, av_bio VARCHAR(200), title TEXT , video_type TEXT CHECK (video_type IN ('url', 'file')), video_data TEXT  )"])
            execute(["ALTER TABLE av add av_id BIGSERIAL PRIMARY KEY"])



        try:
            film = message.text.strip()
        except  ValueError:
            msg = bot.send_message(message.chat.id, "Введите название фильма:")
            safe_register_next_step_handler(msg, user_id, "adding_film", process_film_input)
            return
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton(" Прервать процесс ⛓️‍💥", callback_data="cancel"))
        msg = bot.send_message(message.chat.id, "Введите дату показа (MM.DD.YY):", reply_markup=markup)
        safe_register_next_step_handler(msg, user_id, "adding_film", process_date, film)

    def process_date(message, film):
        user_id = message.from_user.id
        if user_states.get(message.from_user.id) != "adding_film":
            return
        if not admin_check_access_message(message):
            return
        try:
            date = datetime.strptime(message.text.strip(), "%d.%m.%Y").date()
        except ValueError:
            msg = bot.send_message(message.chat.id, "Неверный формат даты. Введите дату в формате дд.мм.гг:")
            safe_register_next_step_handler(msg, user_id, "adding_film", process_date, film)
            return
        trial2("update  dates set picked = 1 where date_name = (%s)", [date])
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton(" Прервать процесс ⛓️‍💥", callback_data="cancel"))
        msg = bot.send_message(message.chat.id, "Введите время показа (чч:мм):", reply_markup=markup)
        safe_register_next_step_handler(msg, user_id, "adding_film", process_time, film, date)

    def process_time(message, film, date):
        user_id = message.from_user.id
        if user_states.get(message.from_user.id) != "adding_film":
            return
        if not admin_check_access_message(message):
            return
        try:
            time1 = datetime.strptime(message.text.strip(), "%H:%M").time()
        except ValueError:
            msg = bot.send_message(message.chat.id, "Неверный формат времени. Введите время в формате ЧЧ:ММ:")
            safe_register_next_step_handler(msg, user_id, "adding_film", process_time, film, date)
            return
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton(" Прервать процесс ⛓️‍💥", callback_data="cancel"))
        msg = bot.send_message(message.chat.id, "Введите длительность сеанса в минутах:", reply_markup=markup)
        safe_register_next_step_handler(msg, user_id, "adding_film", process_delta, film, date, time1)

    def process_delta(message, film, date, time1):
        """"""
        user_id = message.from_user.id
        if user_states.get(message.from_user.id) != "adding_film":
            return
        markup = InlineKeyboardMarkup()
        if not admin_check_access_message(message):
            return
        try:
            delta = int(message.text.strip())
        except ValueError:
            msg = bot.send_message(message.chat.id, "Введите длительность")
            safe_register_next_step_handler(msg, user_id, "adding_film", process_delta, film, date, time1)
            return

        if execute(['select * from temp1']) == 1:
            execute([
                "CREATE TABLE temp1 (mv_title VARCHAR(30), h_id INT REFERENCES halls(h_id),  temp_price INT, temp_date date, temp_time time, temp_delta INT )"])
            execute(["alter table temp1 add t_id BIGSERIAL PRIMARY KEY"])

        trial2("insert into temp1(mv_title, temp_date, temp_time, temp_delta) values(%s,%s, %s, %s)",
               [film, date, time1, delta])

        select = fetchall("select temp_date, temp_time, temp_delta, mv_title from temp1", "")

        for row in select:
            date, time, delta, title = row
            subselect = fetchall(
                "select h_id from av where av_date = (%s) and (av_time + (CAST(av_delta AS TEXT) || ' minutes')::INTERVAL) > (%s)",
                [date, time1])
            if not subselect:
                subsubselect = fetchall("select h_name from halls", '')

                halls = subsubselect

                for hall in halls:


                    hall = hall[0]
                    markup.add(InlineKeyboardButton(f"{hall} 🏛️",
                                                    callback_data=f"fill|{hall}|{time}|{title}|{date}|{delta}"))
                bot.send_message(message.chat.id, "Выберите зал:", reply_markup=markup)
            else:
                bot.send_message(message.chat.id, "Выберите зал:", reply_markup=markup)
                subsubselect = fetchall(
                    "select h_name from halls where h_id not in (select h_id from av where av_date = (%s) and av_time + (CAST(av_delta AS TEXT) || ' minutes')::INTERVAL > (%s))",
                    [date, time1])
                halls = subsubselect
                for hall in halls:
                    hall = hall[0]
                    markup.add(InlineKeyboardButton(f"{hall} 🏛️",
                                                    callback_data=f"fill|{hall}|{time}|{title}|{date}|{delta}"))
                markup.add(InlineKeyboardButton(" Прервать процесс ⛓️‍💥", callback_data="cancel"))
                bot.send_message(message.chat.id, "Выберите зал:", reply_markup=markup)

    def add_price(call):
        """Задаем статус процесса, который будет проверяться в остальных функциях.
        Получаем имя зала, время, название фильма, дату, длительность.
        Получаем кнопку, ай ди записи. Делаем запрос на введение цены."""
        user_id = call.from_user.id
        reset_user_state(user_id)
        user_states[call.from_user.id] = "filling_hall"
        _, h_name, av_time, av_name, av_date, delta = call.data.split("|")
        bot.answer_callback_query(call.id)
        add_price_markup, t_id = add_price_list(h_name, av_time, av_name, av_date, delta)


        msg = bot.send_message(call.message.chat.id, "Введите цену:", reply_markup=add_price_markup)
        safe_register_next_step_handler(msg, user_id,  "filling_hall",  lambda message: set_price(message, t_id))

    def add_price_list(h_name, av_time, av_name, av_date, delta):
        """Выбираем ай ди зала, вставляем его
        во временную таблицу по ключам времени, названия фильма, даты, длительности.
        Выбираем ай ди итоговой временной записи из таблицы.
        Создаем кнопку прервать процесс, получаем кнопку и ай ди"""
        add_price_markup = InlineKeyboardMarkup()


        select = fetchall("SELECT h_id FROM halls WHERE h_name = (%s)", [h_name])

        h_id = select[0][0]

        trial2(
            "UPDATE temp1 SET h_id = (%s) WHERE temp_time = (%s) AND temp_date = (%s) AND mv_title = (%s) AND temp_delta = (%s)",
            [h_id, av_time, av_date, av_name, delta])
        select = fetchall(
            "SELECT t_id FROM temp1 WHERE h_id = (%s) AND temp_time = (%s) AND temp_date = (%s) AND mv_title = (%s) ",
            [h_id, av_time, av_date, av_name])
        t_id = select[0][0]
        add_price_markup.add(InlineKeyboardButton(" Прервать процесс ⛓️‍💥", callback_data="cancel"))
        return add_price_markup, t_id

    def set_price(message, t_id):
        """Проверяем корректность введенной цены.
        Добавляем цену во временную таблицу, по ай ди записи.
        Вставляем в основную таблицу запись из временной, удаляем временную таблицу.
        Добавляем кнопку вернуться в панель админа"""
        user_id = message.from_user.id
        if user_states.get(message.from_user.id) != "filling_hall":
            return
        if not admin_check_access_message(message):
            return
        set_price_markup = InlineKeyboardMarkup()
        try:
            price = message.text.strip()
        except ValueError:
            msg = bot.send_message(message.chat.id, "Неправильный формат цены, введите еще раз")
            safe_register_next_step_handler(msg, user_id, "filling_hall", process_delta, t_id)
            return

        trial2("UPDATE temp1 SET temp_price = (%s) WHERE t_id = (%s)   ", [price, t_id])
        execute([
            "INSERT INTO av (av_time, av_date, av_name, h_id, av_price, av_delta) SELECT temp_time, temp_date, mv_title, h_id, temp_price, temp_delta FROM temp1"])
        execute(["DROP TABLE temp1"])

        set_price_markup.add(InlineKeyboardButton("Назад к панели администратора ↩️", callback_data="admin"))
        bot.send_message(message.chat.id, "Сеансы успешно добавлены! 🎉", reply_markup=set_price_markup)

    def edit(call):
        """Выбираем доступные фильмы, создаем кнопки для них"""
        bot.answer_callback_query(call.id)
        edit_markup = InlineKeyboardMarkup()
        select = fetchall("SELECT DISTINCT av_name FROM av", '')
        for movie in select:
            movie = movie[0]
            edit_markup.add(InlineKeyboardButton(text=f"{movie}", callback_data=f"input|{movie}"))
        bot.send_message(call.message.chat.id, "Выберите фильм", reply_markup=edit_markup)

    def set_bio(call):
        """Получаем информацию о выбранном фильме из def edit.
        Создаем кнопку прервать процесс, делаем запрос на ввод текст от пользователя,
        содержащий описание фильма"""
        user_id = call.from_user.id
        reset_user_state(user_id)
        _, movie = call.data.split("|")
        set_bio_markup = InlineKeyboardMarkup()
        bot.answer_callback_query(call.id)
        user_states[call.from_user.id] = "editing"

        set_bio_markup.add(InlineKeyboardButton(" Прервать процесс ⛓️‍💥", callback_data="cancel"))
        msg = bot.send_message(call.message.chat.id, "Введите описание фильма(максимум 200 символов):", reply_markup=set_bio_markup)

        safe_register_next_step_handler(msg, user_id, "editing",
                                                  lambda message: process_bio(message, movie))
    def process_bio(message, movie):
        """Проверяем корректность введенного, создаем кнопки для
        прерывания процесса, перехода к отправке файла, ссылки на видео """
        user_id = message.from_user.id
        if user_states.get(message.from_user.id) != "editing":
            return
        if not admin_check_access_message(message):
            return
        process_bio_markup = InlineKeyboardMarkup()
        try:
            bio = message.text.strip()
        except  ValueError:
            msg = bot.send_message(message.chat.id, "Ошибка, попробуйте еще раз:")
            safe_register_next_step_handler(msg, user_id, "editing",  process_bio)
            return
        trial2("update av set av_bio = (%s) where av_name = (%s)   ", [bio, movie])
        process_bio_markup.add(InlineKeyboardButton("Файл 📁", callback_data=f"file|{movie}"))
        process_bio_markup.add(InlineKeyboardButton("Ссылка 🕊️", callback_data=f"link|{movie}"))
        process_bio_markup.add(InlineKeyboardButton(" Прервать процесс ⛓️‍💥", callback_data="cancel"))
        bot.send_message(message.chat.id, "Вставьте ссылку на видео или отправьте файл:", reply_markup=process_bio_markup)

    def send_file(call):
        user_id = call.from_user.id
        reset_user_state(user_id)
        """При выборе кнопки файл.
        Получаем название фильма, создаем кнопку прервать процесс,
        делаем запрос на отправку файла"""
        send_markup = InlineKeyboardMarkup()
        bot.answer_callback_query(call.id)
        _, movie = call.data.split("|")
        send_markup.add(InlineKeyboardButton(" Прервать процесс ⛓️‍💥", callback_data="cancel"))
        msg = bot.send_message(call.message.chat.id, "Отправьте файл:", reply_markup=send_markup)
        safe_register_next_step_handler(msg, user_id, "editing", lambda message: upload_file(message, movie))


    def upload_file(message, movie):
        user_id = message.from_user.id
        """Получаем файл, проверяем его, загружаем в таблицу.
        Создаем кнопку вернуть к панели администратора"""
        if user_states.get(message.from_user.id) != "editing":
            return
        if not admin_check_access_message(message):
            return
        upload_file_markup = InlineKeyboardMarkup()
        try:
            file = message.video.file_id
        except ValueError:
            upload_file_markup.add(InlineKeyboardButton(" Прервать процесс ⛓️‍💥", callback_data="cancel"))
            msg = bot.send_message(message.chat.id, "Не удалось загрузить файл, попробуйте снова", reply_markup=upload_file_markup)
            safe_register_next_step_handler(msg, user_id, "editing", upload_file, movie)
            return

        trial2("UPDATE av SET video_type = (%s), video_data = (%s) WHERE av_name = (%s)", ['file', file, movie])
        upload_file_markup.add(InlineKeyboardButton("Назад к панели администратора ↩️", callback_data="admin"))
        bot.send_message(message.chat.id, "Данные успешно добавлены! 🎉", reply_markup=upload_file_markup)

    def send_link(call):
        """При выборе кнопки ссылка.
                Получаем название фильма, создаем кнопку прервать процесс,
                делаем запрос на отправку файла"""
        user_id = call.from_user.id
        reset_user_state(user_id)
        send_link_markup = InlineKeyboardMarkup()
        bot.answer_callback_query(call.id)
        _, movie = call.data.split("|")
        send_link_markup.add(InlineKeyboardButton(" Прервать процесс ⛓️‍💥", callback_data="cancel"))
        msg = bot.send_message(call.message.chat.id, "Отправьте ссылку:", reply_markup=send_link_markup)
        safe_register_next_step_handler(msg, user_id, "editing", lambda message: upload_link(message, movie))

    def upload_link(message, movie):
        """Получаем файл, проверяем его, загружаем в таблицу.
                Создаем кнопку вернуть к панели администратора"""
        user_id = message.from_user.id
        if user_states.get(message.from_user.id) != "editing":
            return
        upload_link_markup = InlineKeyboardMarkup()
        if not admin_check_access_message(message):
            return
        try:
            link = message.text.strip()
        except ValueError:
            upload_link_markup.add(InlineKeyboardButton(" Прервать процесс ⛓️‍💥", callback_data="cancel"))
            msg = bot.send_message(message.chat.id, "Не удалось загрузить файл, попробуйте снова",reply_markup=upload_link_markup)
            safe_register_next_step_handler(msg, user_id, "editing", upload_link, movie)
            return

        trial2("UPDATE av SET video_type = (%s), video_data = (%s) WHERE av_name = (%s)   ", ['url', link, movie])
        upload_link_markup.add(InlineKeyboardButton("Назад к панели администратора ↩️", callback_data="admin"))
        bot.send_message(message.chat.id, "Данные успешно добавлены! 🎉", reply_markup=upload_link_markup)

    @bot.message_handler(commands=['admin'])
    def admin_panel(message):
        if not admin_check_access_message(message):
            return
        show_admin_panel(message.chat.id)

    @bot.callback_query_handler(func=lambda call: call.data == "about_sessions")
    def  about_session(call):
        if not admin_check_access(call):
            return
        get_sessions_info(call)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("curr_decade|"))
    def  show_schedule(call):
        if not admin_check_access(call):
            return
        get_sessions_schedule(call)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("input_decade"))
    def show_sessions(call):
        if not admin_check_access(call):
            return
        get_sessions_schedule_yours(call)

    @bot.callback_query_handler(func=lambda call: call.data == "cancel")
    def cancel_process(call):
        if not admin_check_access(call):
            return
        user_id = call.from_user.id
        if user_id in user_states:
            process_name = user_states.pop(user_id)
            msg = f"Процесс «{process_name}» прерван ✅"
        else:
            msg = "Нет активного процесса для прерывания."

        bot.answer_callback_query(call.id, msg)
        bot.send_message(call.message.chat.id, "Вы вышли из процесса.")
        show_admin_panel(call.message.chat.id)
        print(user_states)

    @bot.callback_query_handler(func=lambda call: call.data == "lobby")
    def destroy(call):
        if not admin_check_access(call):
            return
        choose_option(call)


    @bot.callback_query_handler(func=lambda call: call.data.startswith("options|"))
    def options_for(call):
        if not admin_check_access(call):
            return
        get_deletion(call)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("destroy|"))
    def destroy_for(call):
        if not admin_check_access(call):
            return
        choose_option_to_delete(call)

    @bot.callback_query_handler(func=lambda call:  call.data.startswith("des_all|"))
    def destroy_for(call):
        if not admin_check_access(call):
            return
        ask_to_delete(call)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("desa_ok|"))
    def destroy_for(call):
        if not admin_check_access(call):
            return
        delete(call)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("des_time_for|"))
    def destroy_for_day(call):
        if not admin_check_access(call):
            return
        destroy_some(call)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("des_day|"))
    def destroy_for(call):
        if not admin_check_access(call):
            return
        destroy_day(call)

    @bot.callback_query_handler(func=lambda call: call.data == "halls")
    def create_halls(call):
        if not admin_check_access(call):
            return
        make_halls(call)

    @bot.callback_query_handler(func=lambda call: call.data == "add_session")
    def add_film_session(call):
        if not admin_check_access(call):
            return
        print(user_states)
        add_sessions(call)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("fill|"))
    def handle_fill_option(call):
        if not admin_check_access(call):
            return
        add_price(call)

    @bot.callback_query_handler(func=lambda call: call.data == "edit")
    def edition(call):
        if not admin_check_access(call):
            return
        edit(call)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("input|"))
    def bio_input(call):
        if not admin_check_access(call):
            return
        set_bio(call)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("file|"))
    def handle_file_option(call):
        if not admin_check_access(call):
            return
        send_file(call)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("link|"))
    def handle_link_option(call):
        if not admin_check_access(call):
            return
        send_link(call)

    @bot.callback_query_handler(func=lambda call: call.data == "admin")
    def fallback(call):
        show_admin_panel(call.message.chat.id)