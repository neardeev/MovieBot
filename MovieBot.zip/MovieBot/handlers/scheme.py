from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from db.fetchall import fetchall
from PIL import Image, ImageDraw, ImageFont
import io










def register_scheme(bot):
    def generate_hall_scheme(rows_data, hall_name):

        seat_radius = 12
        seat_diameter = seat_radius * 2
        seat_padding = 10
        font = ImageFont.truetype("arial.ttf", 16)

        max_seats = max(seats for _, seats in rows_data)
        row_count = len(rows_data)

        img_width = (seat_diameter + seat_padding) * max_seats + 200
        img_height = (seat_diameter + seat_padding) * row_count + 200

        img = Image.new("RGB", (img_width, img_height), "white")
        draw = ImageDraw.Draw(img)


        screen_text = "Экран"
        screen_text_width = draw.textlength(screen_text, font=font)
        screen_y = 40
        draw.line(
            [(50, screen_y), (img_width - 50, screen_y)],
            fill="#cccccc",
            width=6
        )
        draw.text(((img_width - screen_text_width) // 2, screen_y + 10), screen_text, fill="#999999", font=font)


        for idx, (row_num, seat_count) in enumerate(rows_data):
            y = 100 + idx * (seat_diameter + seat_padding)


            row_width = (seat_diameter + seat_padding) * seat_count
            x_start = (img_width - row_width) // 2


            label_text = str(row_num)
            label_y = y + seat_radius - 8
            draw.text((20, label_y), label_text, fill="#999999", font=font)
            draw.text((img_width - 40, label_y), label_text, fill="#999999", font=font)


            for seat_idx in range(seat_count):
                x = x_start + seat_idx * (seat_diameter + seat_padding)
                draw.ellipse(
                    [x, y, x + seat_diameter, y + seat_diameter],
                    fill="#00aaff",  # голубой
                    outline="black"
                )


        title = f"Схема зала: {hall_name}"
        title_width = draw.textlength(title, font=font)
        draw.text(((img_width - title_width) // 2, img_height - 40), title, fill="black", font=font)

        return img


    @bot.callback_query_handler(func=lambda call: call.data == "scheme")
    def send_info_new1(call):
        bot.answer_callback_query(call.id)
        select = fetchall(
            "select h_name from halls order by h_name ASC",
            "")
        scheme_markup = InlineKeyboardMarkup()
        scheme_markup.add(InlineKeyboardButton(text="Вернуться в меню ↩️", callback_data="start"))

        for h_name in select:
            h_name = h_name[0]

            scheme_markup.add(InlineKeyboardButton(text=f"{h_name}",
                                                  callback_data=f"info_scheme|{h_name}"))

        bot.send_message(call.message.chat.id, f"Залы (чтобы посмотреть схему нажмите на кнопку):",
                         reply_markup=scheme_markup)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("info_scheme|"))
    def  scheme_info(call):
        _, h_name = call.data.split("|")
        bot.answer_callback_query(call.id)
        select = fetchall("select row_number, count(seat_id) from halls inner join rows using(h_id) inner join seats using(row_id) group by  row_number, h_name having h_name  = (%s)", [h_name])

        img = generate_hall_scheme(select, h_name)
        buf = io.BytesIO()
        img.save(buf, format='PNG')
        buf.seek(0)

        bot.send_photo(call.message.chat.id, buf)
        scheme_markup = InlineKeyboardMarkup()
        scheme_markup.add(InlineKeyboardButton(text="Вернуться в меню ↩️", callback_data="start"))
