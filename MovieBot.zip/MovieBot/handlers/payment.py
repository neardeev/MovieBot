import os

import stripe
from dotenv import load_dotenv
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from db.fetchall import fetchall
from db.trial2 import trial2
from db.execution import execute

load_dotenv()
stripe.api_key = os.getenv("STRIPE_SECRET_KEY")

def register_payment(bot):
    @bot.callback_query_handler(func=lambda call: call.data.startswith("payment|"))
    def payment(call):
        _, res_id = call.data.split("|")
        bot.answer_callback_query(call.id, f"Вы перешли к оплате ✅")
        pay_markup = InlineKeyboardMarkup()

        select = fetchall("""
            SELECT av_price, av.av_name, av.av_date, av.av_time, rows.row_number, seats.seat_number 
            FROM av 
            INNER JOIN rows USING(h_id) 
            INNER JOIN seats USING(row_id) 
            LEFT JOIN res ON res.av_id = av.av_id AND res.row_id = rows.row_id AND res.seat_id = seats.seat_id  
            WHERE r_id = (%s)
            """,[res_id])

        price, title, date, time, row, seat = select[0]
        url, session_id = create_checkout_session(price, res_id)

        execute(["CREATE table if NOT EXISTS pheck (r_id INT REFERENCES res(r_id), sc_id VARCHAR(100)) "])
        trial2("INSERT INTO pheck (r_id, sc_id) VALUES(%s,%s)", [res_id, session_id])

        pay_markup.add(InlineKeyboardButton("Я оплатил ✅", callback_data=f"verify|{res_id}"))
        pay_markup.add(InlineKeyboardButton(text="Вернуться в меню ↩️", callback_data="start"))

        bot.send_message(call.message.chat.id,f"Вы оплачиваете {title}, {date}, {time}, {row}, {seat}\nСумма к оплате {price}руб\n" f'<a href="{url}">Ссылка для оплаты</a>', parse_mode="HTML",reply_markup=pay_markup)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("verify|"))
    def verify_payment(call):
        _, res_id = call.data.split("|")
        bot.answer_callback_query(call.id, f"Проверяем оплату ⌛")
        verify_markup = InlineKeyboardMarkup()

        select = fetchall("""
            SELECT sc_id 
            FROM pheck WHERE r_id = (%s)
            """, [res_id])

        session_id = select[0][0]
        session = stripe.checkout.Session.retrieve(session_id)

        if session.payment_status == 'paid':
            bot.send_message(call.message.chat.id, "Оплата подтверждена! ✅ Спасибо!")
            trial2("UPDATE res SET pay = 1 WHERE r_id = (%s)", [res_id])
        else:
            bot.send_message(call.message.chat.id, "Оплата ещё не подтверждена. ❌ Попробуйте позже.")

        verify_markup.add(InlineKeyboardButton(text="Вернуться в меню ↩️", callback_data="start"))

    def create_checkout_session(price, res_id):
        session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[{
                'price_data': {
                    'currency': 'rub',
                    'unit_amount': price * 100,
                    'product_data': {
                        'name': f'Оплата брони #{res_id}',
                    },
                },
                'quantity': 1,
            }],
            mode='payment',
            success_url=f'https://example.com/success?session_id={{CHECKOUT_SESSION_ID}}',
            cancel_url='https://example.com/cancel',
            metadata={"res_id": res_id}
        )
        return session.url, session.id
