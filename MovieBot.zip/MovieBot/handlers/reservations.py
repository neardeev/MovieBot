from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from db.fetchall import fetchall
from db.trial2 import trial2
import os
import stripe
from dotenv import load_dotenv

load_dotenv()
stripe.api_key = os.getenv("STRIPE_SECRET_KEY")

def register_reservations(bot):
    @bot.callback_query_handler(func=lambda call: call.data == "payed")
    def send_info_new1(call):
        bot.answer_callback_query(call.id)
        user = call.from_user
        payed_markup = InlineKeyboardMarkup()

        select = fetchall(
            "select  av_name,av_date, av_time, seat_number, rows.h_id, r_id, row_number from av  inner join rows using(h_id) inner join seats using(row_id) left join res on res.av_id = av.av_id and res.seat_id = seats.seat_id where cl_name = (%s) and pay = 1 ",
            [str(user.id)])
        payed_markup.add(InlineKeyboardButton(text="Вернуться в меню ↩️", callback_data="start"))

        for movie in select:
            name, date, when, seat, hall, res_id, row = movie

            payed_markup.add(InlineKeyboardButton(text=f"Название: {name} Дата: {date.strftime("%d.%m.%Y")}",
                                                  callback_data=f"info_payed|{res_id}"))

        bot.send_message(call.message.chat.id, f"Ваши сеансы(чтобы посмотреть информацию нажмите на кнопку):",
                         reply_markup=payed_markup)

    @bot.callback_query_handler(func=lambda call: call.data == "reservation")
    def send_info(call):
        bot.answer_callback_query(call.id)
        user = call.from_user
        select = fetchall(
            "select  av_name,av_date, av_time, seat_number, rows.h_id, r_id, row_number from av  inner join rows using(h_id) inner join seats using(row_id) left join res  on res.av_id = av.av_id and res.seat_id = seats.seat_id where cl_name = (%s) and pay = 0 ",
            [str(user.id)])
        res_markup = InlineKeyboardMarkup()
        res_markup.add(InlineKeyboardButton(text="Вернуться в меню ↩️", callback_data="start"))

        for movie in select:
            name, date, when, seat, hall, res_id, row = movie

            res_markup.add(InlineKeyboardButton(text=f"Название: {name} Дата: {date.strftime("%d.%m.%Y")}",
                                                callback_data=f"info_res|{res_id}"))

        bot.send_message(call.message.chat.id, f"Ваши брони (чтобы посмотреть информацию нажмите на кнопку):",
                         reply_markup=res_markup)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("info_res|"))
    def res_info(call):

        _, res_id = call.data.split("|")
        bot.answer_callback_query(call.id)
        info_markup = InlineKeyboardMarkup()

        select = fetchall(
            " select av_name,av_date, av_time, seat_number,  av.h_id, row_number, av_delta, e_time from av  inner join rows using(h_id) inner join seats using(row_id) left join res on res.av_id = av.av_id and res.seat_id = seats.seat_id where r_id = (%s)",
            [res_id])

        name, date, when, seat, hall, row, duration, limit = select[0]
        info_markup.add(InlineKeyboardButton(text="Оплатить бронь 💵", callback_data=f"payment|{res_id}"))
        info_markup.add(InlineKeyboardButton(text="Удалить бронь 🗑️", callback_data=f"del|{res_id}"))
        info_markup.add(InlineKeyboardButton(text="Изменить бронь 🔄", callback_data=f"change|{res_id}"))
        info_markup.add(InlineKeyboardButton(text="Вернуться в меню ↩️", callback_data="start"))
        bot.send_message(call.message.chat.id,
                         f"Ваш сеанс:\nНазвание фильма: {name}\nДата: {date}\nВремя: {when}\nДлительность: {duration}\nМесто: {seat} ,  Ряд: {row}, Зал: {hall}\nОплатить до: {limit}   ",
                         reply_markup=info_markup)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("info_payed|"))
    def payed_info(call):
        _, res_id = call.data.split("|")
        bot.answer_callback_query(call.id)
        info_markup = InlineKeyboardMarkup()
        select = fetchall(
            " select av_name,av_date, av_time, seat_number, row_number, h_id, av_delta from av inner join seats using(h_id) inner join rows using(h_id) left join res on res.av_id = av.av_id and res.seat_id = seats.seat_id where r_id= (%s) ",
            [res_id])

        name, date, when, seat, row, hall, duration = select[0]

        info_markup.add(InlineKeyboardButton(text="Удалить бронь 🗑️", callback_data=f"del|{res_id}"))

        info_markup.add(InlineKeyboardButton(text="Вернуться в меню ↩️", callback_data="start"))
        bot.send_message(call.message.chat.id,
                         f"Ваш сеанс:\nНазвание фильма: {name}\nДата: {date}\nВремя: {when}\nДлительность: {duration}\nМесто: {seat} , Ряд: {row}, Зал: {hall}    ",
                         reply_markup=info_markup)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("del|"))
    def delete(call):
        _, res_id = call.data.split("|")
        bot.answer_callback_query(call.id)
        delete_markup = InlineKeyboardMarkup()
        select = fetchall(
            " select av_name,av_date, av_time, seat_number, row_number, h_id, av_delta from av inner join seats using(h_id) inner join rows using(h_id) left join res  on res.av_id = av.av_id and res.seat_id = seats.seat_id where r_id= (%s) ",
            [res_id])

        name, date, when, seat, row, hall, duration = select[0]

        delete_markup.add(InlineKeyboardButton(text="Да!✔️", callback_data=f"del_ok|{res_id}"))
        if not fetchall("select * from res where pay = 0 and r_id  = (%s)", [res_id]):
            delete_markup.add(
                InlineKeyboardButton(text="Нет!❌", callback_data=f"info_payed|{res_id}"))
        else:
            delete_markup.add(
                InlineKeyboardButton(text="Нет!❌", callback_data=f"info_res|{res_id}"))
        delete_markup.add(InlineKeyboardButton(text="Вернуться в меню ↩️", callback_data="start"))
        bot.send_message(call.message.chat.id,
                         f"Вы уверены что хотите удалить?:\nНазвание фильма: {name}\nДата: {date}\nВремя: {when}\nДлительность: {duration}\nМесто: {seat} , Ряд: {row}, Зал: {hall}    ",
                         reply_markup=delete_markup)



    @bot.callback_query_handler(func=lambda call: call.data.startswith("change|"))
    def change(call):
        _, res_id = call.data.split("|")
        bot.answer_callback_query(call.id)
        change_markup = InlineKeyboardMarkup()
        select = fetchall(
            "select av_name,av_date, av_time, seat_number, row_number, h_id, av_delta from av inner join seats using(h_id) inner join rows using(h_id) left join res  on res.av_id = av.av_id and res.seat_id = seats.seat_id where r_id= (%s) ",
            [res_id])

        name, date, when, seat, row, hall, duration = select[0]

        change_markup.add(InlineKeyboardButton(text="Да!✔️", callback_data=f"change_ok|{res_id}"))
        change_markup.add(
            InlineKeyboardButton(text="Нет!❌", callback_data=f"info_res|{res_id}"))
        change_markup.add(InlineKeyboardButton(text="Вернуться в меню ↩️", callback_data="start"))
        bot.send_message(call.message.chat.id,
                         f"Вы уверены что хотите изменить Ваш сеанс?:\nНазвание фильма: {name}\nДата: {date}\nВремя: {when}\nДлительность: {duration}\nМесто: {seat} , Ряд: {row}, Зал: {hall}    ",
                         reply_markup=change_markup)



    @bot.callback_query_handler(func=lambda call: call.data.startswith("del_ok|"))
    def delete_session(call):
        _, res_id = call.data.split("|")
        bot.answer_callback_query(call.id)
        del_ok_markup = InlineKeyboardMarkup()
        select = fetchall("select pay from res where r_id = (%s)", [res_id])
        pay = select[0][0]



        if pay == 0:
            trial2("delete from pheck where r_id = (%s)", [res_id])
            trial2("delete from res where r_id = (%s)", [res_id])
            del_ok_markup.add(InlineKeyboardButton(text="Назад к сеансам🎥", callback_data="reservation"))
            del_ok_markup.add(InlineKeyboardButton(text="Вернуться в меню ↩️", callback_data="start"))
            bot.send_message(call.message.chat.id,
                             f"успешно удалено",
                             reply_markup=del_ok_markup)
        else:
            select = fetchall("select sc_id from pheck where r_id = (%s)", [res_id])
            trial2("delete from pheck where r_id = (%s)", [res_id])
            trial2("delete from res where r_id = (%s)", [res_id])
            payment_id = select[0][0]

            try:
                intent = stripe.PaymentIntent.retrieve(payment_id)
                charge = intent.charges.data[0].id
                refund = stripe.Refund.create(charge=charge)
                del_ok_markup.add(InlineKeyboardButton(text="Назад к сеансам🎥", callback_data="payed"))
                del_ok_markup.add(InlineKeyboardButton(text="Вернуться в меню ↩️", callback_data="start"))
                bot.send_message(call.message.chat.id,
                                 f"✅ Возврат выполнен: {refund.id}",
                                 reply_markup=del_ok_markup)

            except Exception as e:
                del_ok_markup.add(InlineKeyboardButton(text="Назад к сеансам🎥", callback_data="payed"))
                del_ok_markup.add(InlineKeyboardButton(text="Вернуться в меню ↩️", callback_data="start"))
                bot.send_message(call.message.chat.id,
                                 f"❌ Ошибка: {e}",
                                 reply_markup=del_ok_markup)



    @bot.callback_query_handler(func=lambda call: call.data.startswith("change_ok|"))
    def change_process(call):

        _, res_id = call.data.split("|")
        bot.answer_callback_query(call.id, text="Запись удалена")
        change_ok_markup = InlineKeyboardMarkup()

        select = fetchall(
            "select av_name from av inner join seats using(h_id) inner join rows using(h_id) left join res  on res.av_id = av.av_id and res.seat_id = seats.seat_id where r_id= (%s)  ",
            [res_id])

        movie = select[0][0]
        trial2("delete from pheck where r_id = (%s)", [res_id])
        trial2("delete from res_id where r_id = (%s)", [res_id])

        change_ok_markup.add(InlineKeyboardButton("Выбрать новую дату", callback_data=f"date|{movie}"))

