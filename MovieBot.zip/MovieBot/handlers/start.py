from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton


def register_start(bot):
    @bot.message_handler(commands=["start"])
    def send_welcome(message):
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("Выбрать фильм 🔎", callback_data="generate"))
        markup.add(InlineKeyboardButton("Информация ℹ️", callback_data="info"))
        markup.add(InlineKeyboardButton("Неоплаченные брони ❌", callback_data="reservation"))
        markup.add(InlineKeyboardButton("Оплаченные брони ✔️", callback_data="payed"))
        markup.add(InlineKeyboardButton("Cхема залов 🗺️", callback_data="scheme"))
        bot.reply_to(message, "Привет! С помощью этого бота можно записаться на кино", reply_markup=markup)

    @bot.message_handler(commands=["info"])
    def send_info(message):
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton(text="Вернуться в меню", callback_data="start"))
        bot.reply_to(message, "Это оригинальный проект Ардеева Никиты Евгеньевича \n Ве права защищены",
                     reply_markup=markup)



    @bot.callback_query_handler(func=lambda call: call.data == "start")
    def fallback_start(call):
        send_welcome(call.message)

    @bot.callback_query_handler(func=lambda call: call.data == "info")
    def fallback_info(call):
        send_info(call.message)



