from PIL import Image, ImageDraw, ImageFont
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton

from db.fetchall import fetchall
from db.trial2 import trial2
from db.execution import execute

from datetime import datetime, timedelta
import io


MINUTES = 5


def register_booking(bot):
    """Перешли к разделу бронирований"""
    def draw_scheme(rows_data, hall_name, taken_set=None):
        seat_radius = 12
        seat_diameter = seat_radius * 2
        seat_padding = 6
        font = ImageFont.truetype("arial.ttf", 18)

        max_seats = max(seats for _, seats in rows_data)
        row_count = len(rows_data)

        img_width = (seat_diameter + seat_padding) * max_seats + 200
        img_height = (seat_diameter + seat_padding) * row_count + 250

        img = Image.new("RGB", (img_width, img_height), "#f8f8f8")
        draw = ImageDraw.Draw(img)

        screen_text = "Экран"
        screen_y = 40
        draw.line([(50, screen_y), (img_width - 50, screen_y)], fill="#cccccc", width=6)
        screen_text_width = draw.textlength(screen_text, font=font)
        draw.text(((img_width - screen_text_width) // 2, screen_y + 10), screen_text, fill="#999999", font=font)

        # Ряды
        for idx, (row_num, seat_count) in enumerate(rows_data):
            y = 100 + idx * (seat_diameter + seat_padding)
            row_width = (seat_diameter + seat_padding) * seat_count
            x_start = (img_width - row_width) // 2

            draw.text((20, y + seat_radius - 8), str(row_num), fill="#999999", font=font)
            draw.text((img_width - 40, y + seat_radius - 8), str(row_num), fill="#999999", font=font)

            for seat_idx in range(seat_count):
                x = x_start + seat_idx * (seat_diameter + seat_padding)
                seat_num = seat_idx + 1
                color = "#00aaff"
                if taken_set and (row_num, seat_num) in taken_set:
                    color = "#ff4d4d"

                draw.ellipse([x, y, x + seat_diameter, y + seat_diameter], fill=color, outline="black")
                # Номер места снизу
                seat_label_y = y + seat_diameter + 2
                seat_label = str(seat_num)
                label_width = draw.textlength(seat_label, font=font)
                draw.text((x + seat_radius - label_width / 2, seat_label_y), seat_label, fill="black", font=font)

                # Легенда
            legend_y = img_height - 100
            draw.rectangle([60, legend_y, 80, legend_y + 20], fill="#00aaff", outline="black")
            draw.text((90, legend_y), "Свободно", font=font, fill="black")

            draw.rectangle([180, legend_y, 200, legend_y + 20], fill="#ff4d4d", outline="black")
            draw.text((210, legend_y), "Занято", font=font, fill="black")
        hall_name = hall_name[0]
        title = f"Схема зала: {hall_name}"
        title_width = draw.textlength(title, font=font)
        draw.text(((img_width - title_width) // 2, img_height - 40), title, fill="black", font=font)

        return img

    def generate_scheme_occ(av_name, av_date, av_time):
        hall_id = fetchall("""
            SELECT h_id 
            FROM av 
            WHERE av_name = (%s) AND av_date = (%s) AND av_time = (%s)
        """, [av_name, av_date, av_time])
        hall_id = hall_id[0]

        h_name_data = fetchall("SELECT h_name FROM halls WHERE h_id = (%s)", [hall_id])
        h_name = h_name_data[0]

        rows_data = fetchall("""
            SELECT rows.row_number, COUNT(seats.seat_id)
            FROM rows
            JOIN seats USING(row_id)
            WHERE rows.h_id = (%s)
            GROUP BY rows.row_number
            ORDER BY rows.row_number
        """, [hall_id])

        taken_seats = fetchall("""
            SELECT row_number, seat_number
            FROM av 
            INNER JOIN halls USING(h_id)
            INNER JOIN rows USING(h_id) 
            INNER JOIN seats USING(row_id)
            LEFT JOIN res on res.av_id = av.av_id AND res.row_id = rows.row_id AND res.seat_id = seats.seat_id
            WHERE r_id IS NOT NULL AND av.av_name = (%s) AND av.av_date = (%s) AND av.av_time = (%s)
        """, [av_name, av_date, av_time])
        taken_set = set(taken_seats)
        return draw_scheme(rows_data, h_name, taken_set)

    def film_list(message):
        """Создаем объекты кнопка, выводим их"""
        movie_markup = generate_film_list_markup()
        bot.send_message(message.chat.id, "Выберите фильм:", reply_markup=movie_markup)

    def generate_film_list_markup():
        """Создаем таблицу резерваций, проводим итерацию
         по доступным фильмам. Получаем кнопки для перехода к фильму,
         кнопку для перехода в меню"""
        movie_markup = InlineKeyboardMarkup()

        if execute(["SELECT * FROM res"]) == 1:
            execute(["""CREATE TABLE IF NOT EXISTS res
                            (av_id INT REFERENCES av(av_id), cl_name VARCHAR(30), row_id int references rows(row_id), seat_id INT REFERENCES seats(seat_id), n_time timestamp, pay INT, e_time timestamp)"""])
            execute(["ALTER TABLE res ADD COLUMN r_id BIGSERIAL PRIMARY KEY"])

        movies = fetchall("SELECT DISTINCT av_name FROM av", [])

        for movie in movies:
            movie = movie[0]
            movie_markup.add(InlineKeyboardButton(movie, callback_data=f"choose|{movie}"))

        movie_markup.add(InlineKeyboardButton(text="Вернуться в меню ↩️", callback_data="start"))
        return movie_markup

    def choose_next_step(call):
        """Получаем название выбранного фильма, выводим кнопки с выбором действия"""
        _, movie = call.data.split("|")
        bot.answer_callback_query(call.id)
        choose_markup = choose_next_step_list(movie)
        bot.send_message(call.message.chat.id, f"Фильм:{movie}", reply_markup=choose_markup)

    def choose_next_step_list(movie):
        """Создаем таблицу со свободными датами.
        Создаем кнопки с опциями: выбрать дату, посмотреть информацию о фильме,
        вернуться в меню"""
        choose_markup = InlineKeyboardMarkup()

        available_dates = fetchall("""
                            SELECT DISTINCT av_date
                            FROM av 
                            INNER JOIN rows USING(h_id) 
                            INNER JOIN seats USING(row_id) 
                            LEFT JOIN res ON res.av_id = av.av_id AND res.row_id = rows.row_id AND res.seat_id = seats.seat_id  
                            WHERE av_name = (%s) and r_id IS NULL
                            """, [movie])

        if available_dates:
            choose_markup.add(InlineKeyboardButton(text="Выбрать дату 🗓️", callback_data=f"date|{movie}"))

        choose_markup.add(InlineKeyboardButton(text="О фильме 🎬", callback_data=f"about|{movie}"))
        choose_markup.add(InlineKeyboardButton(text="Вернуться в меню ↩️", callback_data="start"))
        return choose_markup

    def about_movie(call):
        """Получаем названия фильма, выводим информацию о фильме, кнопки: вернуться назад, вернуться в меню"""
        _, movie = call.data.split("|")
        bot.answer_callback_query(call.id)

        about_markup = about_movie_list(movie)

        bio, video_type, video_data, duration = about_movie_data(movie)

        if video_type == "file":
            bot.send_video(call.message.chat.id, video_data,
                       caption=f"Фильм: {movie}\nО фильме: {bio}\nДлительность: {duration}",
                       reply_markup=about_markup)
        elif video_type == "url":
            bot.send_message(call.message.chat.id,
                             f"Фильм: {movie}\nО фильме: {bio}\nДлительность: {duration}\nСсылка на трейлер: {video_data}",
                             reply_markup=about_markup)

    def about_movie_data(movie):
        """Выберем описание фильма, тип медиа, медиа, длительность"""

        movie_data = fetchall("""
                    SELECT DISTINCT av_bio, video_type, video_data, av_delta
                    FROM av
                    WHERE av_name = (%s)
                    """, [movie])

        bio, video_type, video_data, duration = movie_data[0]
        return bio, video_type, video_data, duration

    def about_movie_list(movie):
        """Создадим кнопки для шага назад, возвращения в меню"""

        about_markup = InlineKeyboardMarkup()
        about_markup.add(InlineKeyboardButton(text="Назад 🔙", callback_data=f"choose|{movie}"))
        about_markup.add(InlineKeyboardButton(text="Вернуться в меню ↩️", callback_data="start"))

        return about_markup

    def date_selection(call):
        """Получаем название фильма, выводим кнопку"""
        _, movie = call.data.split("|")
        bot.answer_callback_query(call.id, f"Вы выбрали фильм: {movie} ✅")
        date_markup = date_selection_list(movie)

        bot.send_message(call.message.chat.id, f"Выберите дату для {movie}:", reply_markup=date_markup)

    def date_selection_list(movie):
        """Получим список доступных дат,
        для каждой создадим кнопку.
        Создадим кнопку для перехода в меню и шага назад"""
        date_markup = InlineKeyboardMarkup()

        available_dates = fetchall("""
                    SELECT DISTINCT av_date
                    FROM av 
                    INNER JOIN rows USING(h_id) 
                    INNER JOIN seats USING(row_id) 
                    LEFT JOIN res ON res.av_id = av.av_id AND res.row_id = rows.row_id AND res.seat_id = seats.seat_id  
                    WHERE av_name = (%s) and r_id IS NULL
                    """, [movie])

        for date in available_dates:
            date = date[0].strftime("%d.%m.%Y")
            date_markup.add(InlineKeyboardButton(date, callback_data=f"time|{movie}|{date}"))

        date_markup.add(InlineKeyboardButton(text="Назад 🔙", callback_data=f"choose|{movie}"))
        date_markup.add(InlineKeyboardButton(text="Вернуться в меню ↩️", callback_data="start"))

        return date_markup

    def time_selection(call):
        """Получим название фильма, дату.
        Выведем кнопки выбора времени,
        возвращения на шаг назад и в менб """
        _, movie, date = call.data.split("|")
        bot.answer_callback_query(call.id, f"Вы выбрали дату {date} ✅")
        time_markup = time_selection_list(movie, date)

        bot.send_message(call.message.chat.id, f"Выберите время для {movie}:", reply_markup=time_markup)

    def time_selection_list(movie,date):
        """Выберем доступные даты, создадим кнопку для каждой.
        Создадим кнопку для перехода в меню и шага назад"""
        time_markup = InlineKeyboardMarkup()

        available_times = fetchall("""
                    SELECT DISTINCT av_time 
                    FROM av 
                    INNER JOIN rows USING(h_id) 
                    INNER JOIN seats USING(row_id) 
                    LEFT JOIN res ON res.av_id = av.av_id AND res.row_id = rows.row_id AND res.seat_id = seats.seat_id  
                    WHERE av_name = (%s) AND av_date = (%s) and r_id IS NULL
                    """, [movie, date])

        for time in available_times:
            time = time[0].strftime("%H:%M")
            time_markup.add(InlineKeyboardButton(time, callback_data=f"row|{movie}|{date}|{time}"))

        time_markup.add(InlineKeyboardButton(text="Назад 🔙", callback_data=f"date|{movie}"))
        time_markup.add(InlineKeyboardButton(text="Вернуться в меню ↩️", callback_data="start"))

        return time_markup

    def row_select(call):
        """Получим выбранные:
        название фильма, дату, время.
        Выведем кнопки выбора ряда, возвращения в меню и на шаг назад"""
        _, movie, date, time = call.data.split("|")
        bot.answer_callback_query(call.id, f"Вы выбрали время {time} ✅")
        row_markup = row_select_list(movie, date, time)

        buf = scheme(movie,date,time)

        bot.send_photo(call.message.chat.id, buf, caption="Схема зала")
        bot.send_message(call.message.chat.id, f"Выберите ряд для {movie}:", reply_markup=row_markup)

    def row_select_list(movie, date, time):
        """Выберем номер ряда, для каждого создадим кнопку.
        Создадим кнопки: вернуться в меню, на шаг назад"""
        row_markup = InlineKeyboardMarkup()

        row_numbers = fetchall(
            """
            SELECT DISTINCT row_number
            FROM av 
            INNER JOIN rows USING(h_id) 
            INNER JOIN seats USING(row_id) 
            LEFT JOIN res ON res.av_id = av.av_id AND res.row_id = rows.row_id AND res.seat_id = seats.seat_id  
            WHERE av_name = (%s) AND av_date = (%s) AND av_time = (%s) and r_id IS NULL
            ORDER BY row_number 
            """, [movie, date, time])

        for row in row_numbers:
            row = row[0]
            ids_from_available = fetchall("""
                        SELECT av.av_id, rows.row_id
                        FROM av
                        INNER JOIN rows USING(h_id)
                        LEFT JOIN res ON res.av_id = av.av_id AND res.row_id = rows.row_id
                        WHERE av_name = (%s) AND av_date = (%s) AND av_time = (%s) AND row_number = (%s)
                        """, [movie, date, time, row])

            available_id, row_id = ids_from_available[0]
            row_markup.add(InlineKeyboardButton(row, callback_data=f"seat|{available_id}|{row_id}|{row}"))

        row_markup.add(InlineKeyboardButton(text="Назад 🔙", callback_data=f"time|{movie}|{date}"))
        row_markup.add(InlineKeyboardButton(text="Вернуться в меню ↩️", callback_data="start"))
        return row_markup

    def scheme(movie, date, time):
        """Получение картинки"""
        img = generate_scheme_occ(movie, date, time)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        buf.seek(0)
        return buf

    def seat_select(call):
        """Получим ай ди фильма, ряда, номер ряда,
        выведем кнопки выбора места, выхода в меню"""
        _, available_id, row_id, row = call.data.split("|")
        bot.answer_callback_query(call.id, f"Вы выбрали ряд {row} ✅")
        seat_markup = seat_select_list(available_id,row_id, row)

        bot.send_message(call.message.chat.id, f"Выберите место в ряде {row}:", reply_markup=seat_markup)

    def seat_select_list(available_id, row_id, row):
        """Выведем список мест, для каждого создадим кнопку.
        Создадим кнопку выхода в меню"""
        seat_markup = InlineKeyboardMarkup()

        row_numbers = fetchall("""
                    SELECT seat_number
                    FROM av
                    INNER JOIN rows USING(h_id)
                    INNER JOIN seats USING(row_id) 
                    LEFT JOIN res ON res.av_id = av.av_id AND res.row_id = rows.row_id AND res.seat_id = seats.seat_id  
                    WHERE r_id IS NULL AND  av.av_id = (%s) AND rows.row_id = (%s) AND row_number = (%s) 
                    ORDER BY seat_number
                    """, [available_id, row_id, row])

        for seat in row_numbers:
            seat = seat[0]
            seat_markup.add(
                InlineKeyboardButton(f"Место {seat}", callback_data=f"reservation|{available_id}|{row_id}|{seat}"))

        seat_markup.add(InlineKeyboardButton(text="Вернуться в меню ↩️", callback_data="start"))

        return seat_markup

    def reservation_show(call):
        """Получаем ай ди фильма, юзера, ряда, номер места.
        Получаем ай ди места, время брони, статус оплаты, время окончания брони.
        Выводим кнопки.
        Вставляем в резервации все данные"""
        _, available_id, row_id, seat = call.data.split("|")
        user_id = call.from_user.id
        bot.answer_callback_query(call.id, f"Вы выбрали место {seat} ✅")

        seat_id, current_time, payment, payment_deadline = reservation_show_data(available_id, row_id, seat)
        reservation_show_input(available_id, row_id, seat_id, user_id, current_time, payment, payment_deadline)

        reservation_markup = reservation_make_buttons(user_id, available_id, row_id, seat_id)

        name, date, time, row, seat, hall_name = reservation_show_final_result(user_id, available_id, row_id, seat_id)


        bot.send_message(call.message.chat.id,
                         f"Ваше место успешно забронировано!\nФильм: {name}\nДата: {date}\nВремя: {time}\nЗал: {hall_name}\nРяд: {row}\nМесто: {seat}\nОплата: Нет\nВремя брони {current_time}\nДолжно быть оплачено до {payment_deadline}",
                         reply_markup=reservation_markup)

    def reservation_show_data(available_id, row_id, seat):
        """Выбираем ай ди места, время брони, нулевой статус оплаты,
        время окончания брони"""
        seat_ids = fetchall("""
                    SELECT seats.seat_id 
                    FROM av 
                    INNER JOIN rows USING(h_id) 
                    INNER JOIN seats USING(row_id) 
                    LEFT JOIN res ON res.av_id = av.av_id AND res.row_id = rows.row_id AND res.seat_id = seats.seat_id  
                    WHERE r_id IS NULL AND av.av_id = (%s) AND rows.row_id = (%s) AND seats.seat_number = (%s)
                    """, [available_id, row_id, seat])

        seat_id = seat_ids[0][0]
        current_time = datetime.now().replace(microsecond=0)
        payment = 0
        payment_deadline = (datetime.now() + timedelta(minutes=MINUTES)).replace(microsecond=0)

        return seat_id, current_time, payment, payment_deadline

    def reservation_show_input(available_id, row_id, seat_id, user_id, current_time, payment, payment_deadline):
        """Вставляем в резервации ай ди: фильма, ряда, места, юзера,
        время брони, нулевой статус оплаты, до какого времени оплатить"""
        trial2("""
                    INSERT INTO res (av_id, row_id, seat_id, cl_name, n_time, pay, e_time) 
                    VALUES(%s,%s,%s,%s,%s,%s,%s)
                    """, [available_id, row_id, seat_id, user_id, current_time, payment, payment_deadline])

    def reservation_show_final_result(user_id, available_id, row_id, seat_id):
        """Выбираем название фильма, дату, время, ряд, место, название зала"""
        available_data = fetchall("""
                    SELECT av.av_name, av.av_date, av.av_time, rows.row_number, seats.seat_number, halls.h_name  
                    FROM av
                    INNER JOIN halls USING(h_id)
                    INNER JOIN rows USING(h_id) 
                    INNER JOIN seats USING(row_id) 
                    LEFT JOIN res ON res.av_id = av.av_id AND res.row_id = rows.row_id AND res.seat_id = seats.seat_id  
                    WHERE cl_name =(%s) AND av.av_id = (%s) AND rows.row_id = (%s) AND seats.seat_id = (%s)
                    """, [str(user_id), available_id, row_id, seat_id])

        name, date, time, row, seat, hall_name = available_data[0]

        return name, date, time, row, seat, hall_name

    def reservation_make_buttons(user_id, available_id, row_id, seat_id):
        """Выбираем ай ди резервации.
        Создаем кнопку выхода в меню и перехода к оплате"""
        reservation_markup = InlineKeyboardMarkup()
        reservation_ids = fetchall("""
                    SELECT r_id 
                    FROM av 
                    INNER JOIN rows USING(h_id) 
                    INNER JOIN seats USING(row_id) 
                    LEFT JOIN res ON res.av_id = av.av_id AND res.row_id = rows.row_id AND res.seat_id = seats.seat_id  
                    WHERE cl_name = (%s) AND av.av_id = (%s) AND rows.row_id = (%s) AND seats.seat_id = (%s)
                    """, [str(user_id), available_id, row_id, seat_id])

        reservation_id = reservation_ids[0][0]

        reservation_markup.add(InlineKeyboardButton(text="Вернуться в меню ↩️", callback_data="start"))
        reservation_markup.add(InlineKeyboardButton(text="Оплатить 💳", callback_data=f"payment|{reservation_id}"))
        return reservation_markup

    @bot.message_handler(commands=["generate"])
    def handle_generate_command(message):
        film_list(message)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("choose|"))
    def handle_choose_command(call):
        choose_next_step(call)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("about|"))
    def handle_about_command(call):
        about_movie(call)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("date|"))
    def handle_date_selection(call):
        date_selection(call)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("time|"))
    def handle_time_selection(call):
        time_selection(call)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("row|"))
    def handle_row_selection(call):
         row_select(call)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("seat|"))
    def handle_seat_selection(call):
        seat_select(call)

    @bot.callback_query_handler(func=lambda call: call.data.startswith("reservation|"))
    def handle_reservation_selection(call):
       reservation_show(call)

    @bot.callback_query_handler(func=lambda call: call.data == "generate")
    def fallback_start(call):
        film_list(call.message)