

from .start import register_start
from .reservations import register_reservations
from .payment import register_payment
from .booking import register_booking
from .admin import register_admin
from .scheme import register_scheme

def register_handlers(bot):
    register_start(bot)
    register_reservations(bot)
    register_payment(bot)
    register_booking(bot)
    register_admin(bot)
    register_scheme(bot)
