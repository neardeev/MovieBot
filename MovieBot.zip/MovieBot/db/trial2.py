from psycopg2 import Error #for update, insert, delete
from db.connect import connect

def trial2(command,data ):
    try:
        with connect() as conn:
            cur = conn.cursor()
            cur.execute(command, data)
            try:
                print(cur.fetchone())
            except (Exception, Error):
                pass
            conn.commit()
    except (Exception, Error) as error:
        print("Ошибка при работе  обновлении данных", error)
        return 1
from datetime import time
