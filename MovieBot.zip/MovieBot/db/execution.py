
from psycopg2 import Error


from db.connect import connect



def execute(commands):
    try:
        with connect() as conn:
            cur = conn.cursor()
            for command in commands:
                cur.execute(command)
            try:
                print(cur.fetchone())
            except (Exception, Error):
                pass

            conn.commit()

    except (Exception, Error) as error:
        print("Ошибка при работе  обновлении данных", error)
        return 1

