from psycopg2 import Error #for select option
from db.connect import connect

def fetchall(command,data ):
    try:
        with connect() as conn:
            cur = conn.cursor()
            cur.execute(command, data)
            conn.commit()
    except (Exception, Error) as error:
        pass
        print("Ошибка при работе  обновлении данных", error)
    return cur.fetchall()

